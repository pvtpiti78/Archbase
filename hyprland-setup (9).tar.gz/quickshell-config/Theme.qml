pragma Singleton
import QtQuick

QtObject {
    // Tokyo Night Dark
    readonly property color bg:         "#1a1b26"
    readonly property color bgDark:     "#16161e"
    readonly property color bgHighlight:"#292e42"
    readonly property color fg:         "#c0caf5"
    readonly property color fgDim:      "#787c99"
    readonly property color border:     "#3b4261"
    readonly property color accent:     "#7aa2f7"
    readonly property color red:        "#f7768e"
    readonly property color green:      "#9ece6a"
    readonly property color yellow:     "#e0af68"
    readonly property color blue:       "#7aa2f7"
    readonly property color magenta:    "#bb9af7"
    readonly property color cyan:       "#7dcfff"

    // Bar
    readonly property int barHeight:    34
    readonly property int radius:       8
    readonly property int spacing:      8
    readonly property int padding:      12

    // Font
    readonly property string font:      "JetBrainsMono Nerd Font"
    readonly property int fontSize:     13
    readonly property int iconSize:     16
}
