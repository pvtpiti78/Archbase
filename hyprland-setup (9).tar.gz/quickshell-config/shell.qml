import Quickshell
import "bar"
import "powermenu"

ShellRoot {
    property bool showPowerMenu: false
    Bar { menuVisible: showPowerMenu; onMenuToggled: showPowerMenu = !showPowerMenu }
    PowerMenu { visible: showPowerMenu; onClose: showPowerMenu = false }
}
