import QtQuick
import "../"

Rectangle {
    id: powerBtn
    width: 28
    height: 28
    radius: Theme.radius
    color: hovered ? Theme.red : "transparent"
    border.color: hovered ? Theme.red : Theme.border
    border.width: 1

    property bool hovered: false
    property bool menuOpen: false

    Text {
        anchors.centerIn: parent
        text: "⏻"
        color: parent.hovered ? Theme.bg : Theme.fgDim
        font.pixelSize: Theme.iconSize
    }

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onEntered: parent.hovered = true
        onExited: parent.hovered = false
        onClicked: powerBtn.menuOpen = !powerBtn.menuOpen
    }
}
