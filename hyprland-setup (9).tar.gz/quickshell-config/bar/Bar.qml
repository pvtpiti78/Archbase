import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import Quickshell.Io
import QtQuick
import "../"
import "../powermenu"

Variants {
    property bool menuVisible: false
    signal menuToggled()

    model: Quickshell.screens

    PanelWindow {
        property var modelData

        screen: modelData
        anchors.top: true
        anchors.left: true
        anchors.right: true
        implicitHeight: Theme.barHeight
        color: "transparent"
        margins.bottom: 4

        Rectangle {
            anchors.fill: parent
            anchors.margins: 4
            color: Theme.bg
            radius: Theme.radius
            border.color: Theme.border
            border.width: 1

            // Left
            WorkspaceWidget {
                anchors.left: parent.left
                anchors.leftMargin: Theme.padding
                anchors.verticalCenter: parent.verticalCenter
            }

            // Center
            ClockWidget {
                anchors.centerIn: parent
            }

            // Right
            Row {
                anchors.right: parent.right
                anchors.rightMargin: Theme.padding
                anchors.verticalCenter: parent.verticalCenter
                spacing: Theme.spacing

                SystemTrayWidget {}

                Rectangle {
                    id: powerBtn
                    width: 28
                    height: 28
                    radius: Theme.radius
                    color: hovered ? Theme.red : "transparent"
                    border.color: hovered ? Theme.red : Theme.border
                    border.width: 1

                    property bool hovered: false

                    Text {
                        anchors.centerIn: parent
                        text: "⏻"
                        color: parent.hovered ? Theme.bg : Theme.fgDim
                        font.pixelSize: Theme.iconSize
                    }

                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onEntered: parent.hovered = true
                        onExited: parent.hovered = false
                        onClicked: menuToggled()
                    }
                }
            }
        }
    }
}
