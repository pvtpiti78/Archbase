import Quickshell
import Quickshell.Services.SystemTray
import QtQuick
import QtQuick.Layouts
import "../"

RowLayout {
    spacing: 4

    Repeater {
        model: SystemTray.items

        Item {
            required property SystemTrayItem modelData

            width: 24
            height: 24

            Image {
                anchors.centerIn: parent
                source: modelData.icon
                width: Theme.iconSize
                height: Theme.iconSize
                smooth: true
            }

            MouseArea {
                anchors.fill: parent
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                onClicked: (mouse) => {
                    if (mouse.button === Qt.RightButton)
                        modelData.activate(mouseX, mouseY)
                    else
                        modelData.activate(mouseX, mouseY)
                }
            }
        }
    }
}
