import Quickshell
import Quickshell.Io
import QtQuick
import "../"

Row {
    spacing: 8

    Text {
        id: timeText
        color: Theme.fg
        font.family: Theme.font
        font.pixelSize: Theme.fontSize
        font.bold: true
    }

    Text {
        id: dateText
        color: Theme.fgDim
        font.family: Theme.font
        font.pixelSize: Theme.fontSize
    }

    Timer {
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: {
            var now = new Date()
            timeText.text = Qt.formatTime(now, "hh:mm:ss")
            dateText.text = Qt.formatDate(now, "ddd dd.MM.yyyy")
        }
    }
}
