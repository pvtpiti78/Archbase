import Quickshell
import Quickshell.Hyprland
import QtQuick
import QtQuick.Layouts
import "../"

RowLayout {
    spacing: 4

    Repeater {
        model: Hyprland.workspaces

        Rectangle {
            required property HyprlandWorkspace modelData

            width: 24
            height: 24
            radius: Theme.radius
            color: modelData.active ? Theme.accent :
                   modelData.windows > 0 ? Theme.bgHighlight :
                   Theme.bgDark
            border.color: modelData.active ? Theme.accent : Theme.border
            border.width: 1

            Text {
                anchors.centerIn: parent
                text: modelData.id
                color: modelData.active ? Theme.bg : Theme.fgDim
                font.family: Theme.font
                font.pixelSize: Theme.fontSize - 2
                font.bold: modelData.active
            }

            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: Hyprland.dispatch("workspace " + modelData.id)
            }
        }
    }
}
