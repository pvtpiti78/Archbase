import Quickshell
import Quickshell.Hyprland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import "../"

FloatingWindow {
    id: powerMenu
    visible: false
    implicitWidth: 200
    implicitHeight: 160
    signal close()

    Rectangle {
        anchors.fill: parent
        color: Theme.bg
        radius: Theme.radius
        border.color: Theme.border
        border.width: 1

        ColumnLayout {
            anchors.centerIn: parent
            spacing: 8
            width: parent.width - 32

            Text {
                Layout.alignment: Qt.AlignHCenter
                text: "Power"
                color: Theme.fg
                font.family: Theme.font
                font.pixelSize: Theme.fontSize
                font.bold: true
            }

            PowerMenuButton {
                Layout.fillWidth: true
                label: "  Shutdown"
                buttonColor: Theme.red
                onClicked: {
                    powerMenu.close()
                    shutdownProcess.running = true
                }
                Process {
                    id: shutdownProcess
                    command: ["systemctl", "poweroff"]
                }
            }

            PowerMenuButton {
                Layout.fillWidth: true
                label: "  Reboot"
                buttonColor: Theme.yellow
                onClicked: {
                    powerMenu.close()
                    rebootProcess.running = true
                }
                Process {
                    id: rebootProcess
                    command: ["systemctl", "reboot"]
                }
            }

            PowerMenuButton {
                Layout.fillWidth: true
                label: "  Logout"
                buttonColor: Theme.blue
                onClicked: {
                    powerMenu.close()
                    Hyprland.dispatch("exit")
                }
            }
        }
    }
}
