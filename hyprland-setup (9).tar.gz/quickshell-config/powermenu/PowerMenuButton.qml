import QtQuick
import QtQuick.Layouts
import "../"

Rectangle {
    property string label: ""
    property color buttonColor: Theme.accent
    signal clicked()

    Layout.fillWidth: true
    height: 36
    radius: Theme.radius
    color: hovered ? Qt.rgba(buttonColor.r, buttonColor.g, buttonColor.b, 0.2) : Theme.bgDark
    border.color: hovered ? buttonColor : Theme.border
    border.width: 1

    property bool hovered: false

    Text {
        anchors.centerIn: parent
        text: label
        color: parent.hovered ? parent.buttonColor : Theme.fg
        font.family: Theme.font
        font.pixelSize: Theme.fontSize
    }

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onEntered: parent.hovered = true
        onExited: parent.hovered = false
        onClicked: parent.clicked()
    }
}
