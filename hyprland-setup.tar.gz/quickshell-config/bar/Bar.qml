import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import "../"
import "../powermenu"

Variants {
    property bool menuVisible: false
    signal menuToggled()

    model: Quickshell.screens

    PanelWindow {
        property var modelData

        screen: modelData
        anchors.top: true
        anchors.left: true
        anchors.right: true
        implicitHeight: Theme.barHeight + 8
        color: "transparent"

        Rectangle {
            anchors.fill: parent
            anchors.margins: 4
            color: Theme.bg
            radius: Theme.radius
            border.color: Theme.border
            border.width: 1

            // Left — Workspaces
            WorkspaceWidget {
                anchors.left: parent.left
                anchors.leftMargin: Theme.padding
                anchors.verticalCenter: parent.verticalCenter
            }

            // Center — Clock
            ClockWidget {
                anchors.centerIn: parent
            }

            // Right — Tray + Volume + Power
            RowLayout {
                anchors.right: parent.right
                anchors.rightMargin: Theme.padding
                anchors.verticalCenter: parent.verticalCenter
                spacing: Theme.spacing

                SystemTrayWidget {}

                VolumeWidget {}

                // Power button
                Rectangle {
                    width: 26
                    height: 26
                    radius: Theme.radius
                    color: hovered ? Qt.rgba(Theme.red.r, Theme.red.g, Theme.red.b, 0.15) : "transparent"
                    border.color: hovered ? Theme.red : Theme.border
                    border.width: 1

                    property bool hovered: false

                    Behavior on color { ColorAnimation { duration: 120 } }
                    Behavior on border.color { ColorAnimation { duration: 120 } }

                    Text {
                        anchors.centerIn: parent
                        text: "⏻"
                        color: parent.hovered ? Theme.red : Theme.fgDim
                        font.pixelSize: Theme.iconSize
                        Behavior on color { ColorAnimation { duration: 120 } }
                    }

                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onEntered: parent.hovered = true
                        onExited: parent.hovered = false
                        onClicked: menuToggled()
                    }
                }
            }
        }
    }
}
