import QtQuick
import "../"

Column {
    spacing: 0

    Text {
        id: timeText
        anchors.horizontalCenter: parent.horizontalCenter
        color: Theme.fg
        font.family: Theme.font
        font.pixelSize: Theme.fontSize
        font.bold: true
    }

    Text {
        id: dateText
        anchors.horizontalCenter: parent.horizontalCenter
        color: Theme.fgDim
        font.family: Theme.font
        font.pixelSize: Theme.fontSize - 2
    }

    Timer {
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: {
            var now = new Date()
            timeText.text = Qt.formatTime(now, "hh:mm:ss")
            dateText.text = Qt.formatDate(now, "ddd dd.MM.yyyy")
        }
    }
}
