import Quickshell
import Quickshell.Io
import QtQuick
import "../"

Row {
    spacing: 4

    property string volume: "??"
    property bool muted: false

    Text {
        text: parent.muted ? "󰝟" : (parseInt(parent.volume) > 50 ? "󰕾" : (parseInt(parent.volume) > 0 ? "󰖀" : "󰕿"))
        color: parent.muted ? Theme.red : Theme.fgDim
        font.family: Theme.font
        font.pixelSize: Theme.iconSize
    }

    Text {
        text: parent.muted ? "MUT" : parent.volume + "%"
        color: parent.muted ? Theme.red : Theme.fgDim
        font.family: Theme.font
        font.pixelSize: Theme.fontSize - 1
    }

    Process {
        id: volProcess
        command: ["bash", "-c", "wpctl get-volume @DEFAULT_AUDIO_SINK@"]
        running: true
        onExited: {
            var out = stdout.trim()
            if (out.includes("MUTED")) {
                parent.muted = true
                parent.volume = out.replace(/[^0-9.]/g, "")
                parent.volume = Math.round(parseFloat(parent.volume) * 100) + ""
            } else {
                parent.muted = false
                var match = out.match(/[\d.]+/)
                if (match) parent.volume = Math.round(parseFloat(match[0]) * 100) + ""
            }
        }
        stdout: SplitParser {}
    }

    Timer {
        interval: 2000
        running: true
        repeat: true
        onTriggered: volProcess.running = true
    }
}
