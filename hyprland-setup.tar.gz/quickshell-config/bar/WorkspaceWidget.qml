import Quickshell
import Quickshell.Hyprland
import QtQuick
import QtQuick.Layouts
import "../"

RowLayout {
    spacing: 5

    Repeater {
        model: Hyprland.workspaces

        Rectangle {
            required property HyprlandWorkspace modelData

            width: modelData.active ? 28 : (modelData.windows > 0 ? 20 : 16)
            height: 8
            radius: 4
            color: modelData.active ? Theme.accent :
                   modelData.windows > 0 ? Theme.fgDim :
                   Theme.bgHighlight

            Behavior on width { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
            Behavior on color { ColorAnimation { duration: 150 } }

            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: Hyprland.dispatch("workspace " + modelData.id)
            }
        }
    }
}
