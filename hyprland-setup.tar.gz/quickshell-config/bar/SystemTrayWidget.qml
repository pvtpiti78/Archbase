import Quickshell
import Quickshell.Services.SystemTray
import QtQuick
import QtQuick.Layouts
import "../"

RowLayout {
    spacing: 4

    Repeater {
        model: SystemTray.items

        Item {
            required property SystemTrayItem modelData

            width: 22
            height: 22

            Image {
                anchors.centerIn: parent
                source: modelData.icon
                width: Theme.iconSize
                height: Theme.iconSize
                smooth: true
                mipmap: true
            }

            MouseArea {
                anchors.fill: parent
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                cursorShape: Qt.PointingHandCursor
                onClicked: (mouse) => {
                    if (mouse.button === Qt.RightButton)
                        modelData.activate(mouseX, mouseY)
                    else
                        modelData.activate(mouseX, mouseY)
                }
            }
        }
    }
}
